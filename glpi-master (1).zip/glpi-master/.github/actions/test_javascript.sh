#!/bin/bash -e

npm run-script test
